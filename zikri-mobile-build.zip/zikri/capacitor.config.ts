import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.ziademad.zikri',
  appName: 'ذِكري | ZIKRI',
  webDir: 'out',
  bundledWebRuntime: false,
  android: {
    allowMixedContent: false
  }
};

export default config;
